package com.meliskara.sugarcheckapplication

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*

class InsulinPage : AppCompatActivity() {

    object counter{
        var counter = 0
        var sum = 0
    }

    lateinit var getWeight : TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insulin_page)

        if (SharedPrefManager.getInstance(this).isLoggedIn) {

            
        }


        val morningInsulin = findViewById<EditText>(R.id.morningInsulin)
        val noonInsulin = findViewById<EditText>(R.id.noonInsulin)
        val dinnerInsulin = findViewById<EditText>(R.id.dinnerInsulin)
        val nightInsulin = findViewById<EditText>(R.id.nightInsulin)


        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)


        morningInsulin.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningInsulin" ,"0"))
        noonInsulin.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonInsulin" ,"0"))
        dinnerInsulin.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerInsulin" ,"0"))
        nightInsulin.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "nightInsulin" ,"0"))

    }


    fun saveInsulin(view: View){
        val morningInsulin = findViewById<EditText>(R.id.morningInsulin).text.toString()
        val noonInsulin = findViewById<EditText>(R.id.noonInsulin).text.toString()
        val dinnerInsulin = findViewById<EditText>(R.id.dinnerInsulin).text.toString()
        val nightInsulin = findViewById<EditText>(R.id.nightInsulin).text.toString()


        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "morningInsulin", morningInsulin).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "noonInsulin",  noonInsulin).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "dinnerInsulin", dinnerInsulin).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "nightInsulin", nightInsulin).apply()

        if(morningInsulin != "0" && morningInsulin.toInt()>0){
            counter.counter++
            counter.sum += morningInsulin.toInt()
        }
        else if (morningInsulin == "0" ){
        }
        else{
            Toast.makeText(applicationContext," morninginsulin is invalid", Toast.LENGTH_SHORT).show()
        }


        if(noonInsulin != "0" && noonInsulin.toInt()>0){
            counter.counter++
            counter.sum += noonInsulin.toInt()
        }
        else if (noonInsulin == "0" ){
        }
        else{
            Toast.makeText(applicationContext," nooninsulin is invalid", Toast.LENGTH_SHORT).show()
        }


        if(dinnerInsulin != "0" && dinnerInsulin.toInt()>0){
            counter.counter++
            counter.sum += dinnerInsulin.toInt()
        }
        else if (dinnerInsulin == "0" ){
        }
        else{
            Toast.makeText(applicationContext," dinnerinsulin is invalid", Toast.LENGTH_SHORT).show()
        }



        if(nightInsulin != "0" && nightInsulin.toInt()>0){
            counter.counter++
            counter.sum += nightInsulin.toInt()
        }
        else if (nightInsulin == "0" ){
        }
        else{
            Toast.makeText(applicationContext," noonSatiety is invalid", Toast.LENGTH_SHORT).show()
        }


        val arithmeticInsulin = counter.sum/counter.counter
        findViewById<TextView>(R.id.arithmeticInsulin).text = arithmeticInsulin.toString()



        counter.counter = 0
        counter.sum = 0


        val wGet = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "weight","0").toString().toInt()


        if(arithmeticInsulin*4 <= wGet){
            findViewById<TextView>(R.id.textInsulin).text =  "Your Weight => "+ wGet +" Insulin levels are appropriate."
        }
        else{
                findViewById<TextView>(R.id.textInsulin).text = "Your Weight => "+ wGet +" You are making too much insulin!!!"
        }



    }


    fun resetInsulin(view: View){

        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "morningInsulin", "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "noonInsulin",  "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "dinnerInsulin", "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "nightInsulin", "0").apply()


        findViewById<TextView>(R.id.morningInsulin).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningInsulin", "0")
        findViewById<TextView>(R.id.noonInsulin).text =sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonInsulin", "0")

        findViewById<TextView>(R.id.dinnerInsulin).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerInsulin", "0")
        findViewById<TextView>(R.id.nightInsulin).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "nightInsulin", "0")

        findViewById<TextView>(R.id.arithmeticInsulin).text = "0"
        //findViewById<TextView>(R.id.getWeight).text = " "
        findViewById<TextView>(R.id.textInsulin).text = " "

    }

    fun openInsulinGraph(view: View){
        startActivity(Intent(this,InsulinGraph::class.java))

    }

    fun returnMain(view: View){
        startActivity(Intent(this,MainActivity::class.java))

    }



}