package com.meliskara.sugarcheckapplication

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.meliskara.sugarcheckapplication.databinding.ActivityInsulinGraphBinding
import com.meliskara.sugarcheckapplication.databinding.ActivitySugarLevelsGraphBinding

class SugarLevelsGraph : AppCompatActivity() {
    private lateinit var binding: ActivitySugarLevelsGraphBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySugarLevelsGraphBinding.inflate(layoutInflater)
        val view = binding.root

        setContentView(view)

        val barEntry = arrayListOf<BarEntry>()
        val date = arrayOf("Morning","Noon","Dinner")

        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)
        val sugarbar1 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningHunger","0").toString()
        val sugarbar2 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningSatiety","0").toString()
        val sugarbar3 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonHunger","0").toString()
        val sugarbar4 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonSatiety","0").toString()
        val sugarbar5 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerHunger","0").toString()
        val sugarbar6 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerSatiety","0").toString()


        val morningArth = (sugarbar1.toFloat()+sugarbar2.toFloat())/2
        val noonArth = (sugarbar3.toFloat()+sugarbar4.toFloat())/2
        val dinnerArth = (sugarbar5.toFloat()+sugarbar6.toFloat())/2

        barEntry.add(BarEntry(0f,(sugarbar1.toFloat()+sugarbar2.toFloat())/2))
        barEntry.add(BarEntry(1f,(sugarbar3.toFloat()+sugarbar4.toFloat())/2))
        barEntry.add(BarEntry(2f,(sugarbar5.toFloat()+sugarbar6.toFloat())/2))

        val barDataSet = BarDataSet(barEntry,"Sugar Levels")
        barDataSet.valueTextSize = 15f
        barDataSet.setColors(*ColorTemplate.MATERIAL_COLORS)

        val barData = BarData(barDataSet)
        binding.barChart.animateY(1500)
        binding.barChart.setFitBars(true)
        binding.barChart.data = barData
        binding.barChart.description.text = "Time"
        binding.barChart.xAxis.valueFormatter = IndexAxisValueFormatter(date)
        binding.barChart.xAxis.position = XAxis.XAxisPosition.BOTTOM

        //PieChart
        val pieEntry = arrayListOf<PieEntry>()
        pieEntry.add(PieEntry(morningArth,"Morning"))
        pieEntry.add(PieEntry(noonArth,"Noon"))
        pieEntry.add(PieEntry(dinnerArth,"Dinner"))

        val pieDataSet = PieDataSet(pieEntry,"Sugar Levels")
        pieDataSet.valueTextSize = 15f
        pieDataSet.setColors(*ColorTemplate.COLORFUL_COLORS)

        val pieData = PieData(pieDataSet)

        binding.pieChart.data = pieData
        binding.pieChart.description.text = "Time"
        binding.pieChart.centerText = "Sugar Levels"


    }

    fun returnMain4(view: View){
        startActivity(Intent(this,MainActivity::class.java))

    }
}