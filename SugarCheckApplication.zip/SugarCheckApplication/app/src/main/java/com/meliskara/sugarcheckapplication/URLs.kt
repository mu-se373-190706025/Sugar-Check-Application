package com.meliskara.sugarcheckapplication

object URLs {

    val URL_LOGIN = "http://192.168.1.107:8080/indexlogin.php/"
    val URL_REGISTER = "http://192.168.1.107:8080/indexregister.php/"
    val URL_DELETE = "http://192.168.1.107:8080/indexdelete.php/"
}