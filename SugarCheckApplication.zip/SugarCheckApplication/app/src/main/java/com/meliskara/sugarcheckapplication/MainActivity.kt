package com.meliskara.sugarcheckapplication

import android.content.Context
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), View.OnClickListener {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (SharedPrefManager.getInstance(this).isLoggedIn) {
            val btnLogout = findViewById<Button>(R.id.buttonLogout)

            val weight = findViewById<EditText>(R.id.textViewWeight)
            val height = findViewById<EditText>(R.id.textViewHeight)
            val age = findViewById<EditText>(R.id.textViewAge)

            val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
                Context.MODE_PRIVATE)


            if(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "weight"," ") == " "){
                weight.setText("-")
            }
            else{
                weight.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "weight" ," "))
            }


            if(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "height"," ") == " "){
                height.setText("-")
            }
            else{
                height.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "height" ," "))
            }


            if(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "age"," ") == " "){
                age.setText("-")
            }


            else{
                age.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "age" ," "))
            }

            val user = SharedPrefManager.getInstance(this).user


            btnLogout.setOnClickListener(this)

        } else {
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }





    }

    override fun onClick(view: View) {
        val btnLogout = findViewById<Button>(R.id.buttonLogout)
        if (view == btnLogout) {
            SharedPrefManager.getInstance(applicationContext).logout()
        }
    }

    fun changeWeight(view: View){
        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        val weight = findViewById<EditText>(R.id.textViewWeight).text.toString()

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "weight" , weight).apply()

        Toast.makeText(applicationContext,"Entered weight saved.", Toast.LENGTH_SHORT).show()


    }

    fun changeHeight(view: View){
        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        val height = findViewById<EditText>(R.id.textViewHeight).text.toString()

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "height" , height).apply()

        Toast.makeText(applicationContext,"Entered height saved.", Toast.LENGTH_SHORT).show()


    }

    fun changeAge(view: View){
        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        val age = findViewById<EditText>(R.id.textViewAge).text.toString()

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "age" , age).apply()

        Toast.makeText(applicationContext,"Entered age saved.", Toast.LENGTH_SHORT).show()


    }

    fun goSugarPage(view: View){
        startActivity(Intent(this,SugarPage::class.java))
    }

    fun goInsulinPage(view: View){
        startActivity(Intent(this,InsulinPage::class.java))
    }
}