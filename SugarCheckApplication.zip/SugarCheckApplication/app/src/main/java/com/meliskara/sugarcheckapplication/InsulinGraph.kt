package com.meliskara.sugarcheckapplication

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.meliskara.sugarcheckapplication.databinding.ActivityInsulinGraphBinding

class InsulinGraph : AppCompatActivity() {

    private lateinit var binding: ActivityInsulinGraphBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityInsulinGraphBinding.inflate(layoutInflater)
        val view = binding.root

        setContentView(view)

        val barEntry = arrayListOf<BarEntry>()
        val date = arrayOf("Morning","Noon","Dinner","Night")

        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)
        val bar1 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningInsulin","0").toString()
        val bar2 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonInsulin","0").toString()
        val bar3 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerInsulin","0").toString()
        val bar4 = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "nightInsulin","0").toString()

        barEntry.add(BarEntry(0f,bar1.toFloat()))
        barEntry.add(BarEntry(1f,bar2.toFloat()))
        barEntry.add(BarEntry(2f,bar3.toFloat()))
        barEntry.add(BarEntry(3f,bar4.toFloat()))

        val barDataSet = BarDataSet(barEntry,"Insulin Levels")
        barDataSet.valueTextSize = 15f
        barDataSet.setColors(*ColorTemplate.MATERIAL_COLORS)

        val barData = BarData(barDataSet)
        binding.barChart.animateY(1500)
        binding.barChart.setFitBars(true)
        binding.barChart.data = barData
        binding.barChart.description.text = "Time"
        binding.barChart.xAxis.valueFormatter = IndexAxisValueFormatter(date)
        binding.barChart.xAxis.position = XAxis.XAxisPosition.BOTTOM

        //PieChart
        val pieEntry = arrayListOf<PieEntry>()
        pieEntry.add(PieEntry(bar1.toFloat(),"Morning"))
        pieEntry.add(PieEntry(bar2.toFloat(),"Noon"))
        pieEntry.add(PieEntry(bar3.toFloat(),"Dinner"))
        pieEntry.add(PieEntry(bar4.toFloat(),"Night"))

        val pieDataSet = PieDataSet(pieEntry,"Insulin Levels")
        pieDataSet.valueTextSize = 15f
        pieDataSet.setColors(*ColorTemplate.COLORFUL_COLORS)

        val pieData = PieData(pieDataSet)

        binding.pieChart.data = pieData
        binding.pieChart.description.text = "Time"
        binding.pieChart.centerText = "Insulin Levels"


    }

    fun returnMain3(view: View){
        startActivity(Intent(this,MainActivity::class.java))

    }
}

