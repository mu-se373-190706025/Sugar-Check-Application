package com.meliskara.sugarcheckapplication

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class SugarPage : AppCompatActivity() {

    object counter{
        var counter = 0
        var sum = 0
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sugar_page)

        if (SharedPrefManager.getInstance(this).isLoggedIn) {

        }

            val morningHunger = findViewById<EditText>(R.id.morningHunger)
            val morningSatiety = findViewById<EditText>(R.id.morningSatiety)

            val noonHunger = findViewById<EditText>(R.id.noonHunger)
            val noonSatiety = findViewById<EditText>(R.id.noonSatiety)


            val dinnerHunger = findViewById<EditText>(R.id.dinnerHunger)
            val dinnerSatiety = findViewById<EditText>(R.id.dinnerSatiety)

            val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
                Context.MODE_PRIVATE)

            //mood

            val radioMood  = findViewById<RadioGroup>(R.id.radioMood)
            val  mood = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "mood" ,"Neutral").toString()

            if(mood=="Happy"){
                val rMood = findViewById<RadioButton>(R.id.happyRadioButton)
                radioMood.check(rMood.id)
            }
            else if(mood == "Neutral"){
                val rMood = findViewById<RadioButton>(R.id.neutralRadioButton)
                radioMood.check(rMood.id)

            }
            else{
                val rMood = findViewById<RadioButton>(R.id.sadRadioButton)
                radioMood.check(rMood.id)

            }

        morningHunger.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningHunger" ,"0"))
        morningSatiety.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningSatiety" ,"0"))


        noonHunger.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonHunger" ,"0"))
        noonSatiety.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonSatiety" ,"0"))

        dinnerHunger.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerHunger" ,"0"))
        dinnerSatiety.setText(sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerSatiety" ,"0"))


    }


    fun save(view: View){
        val morningHunger = findViewById<EditText>(R.id.morningHunger).text.toString()
        val morningSatiety = findViewById<EditText>(R.id.morningSatiety).text.toString()

        val noonHunger = findViewById<EditText>(R.id.noonHunger).text.toString()
        val noonSatiety = findViewById<EditText>(R.id.noonSatiety).text.toString()


        val dinnerHunger = findViewById<EditText>(R.id.dinnerHunger).text.toString()
        val dinnerSatiety = findViewById<EditText>(R.id.dinnerSatiety).text.toString()

        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "morningHunger", morningHunger).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "morningSatiety",  morningSatiety).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "noonHunger", noonHunger).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "noonSatiety", noonSatiety).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "dinnerHunger", dinnerHunger).apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "dinnerSatiety", dinnerSatiety).apply()

        if(morningHunger != "0" && morningHunger.toInt()>0){
            counter.counter++
            counter.sum += morningHunger.toInt()
        }
        else if (morningHunger == "0" ){
        }
        else{
            Toast.makeText(applicationContext," morningHunger is invalid",Toast.LENGTH_SHORT).show()
        }


        if(morningSatiety != "0" && morningSatiety.toInt()>0){
            counter.counter++
            counter.sum += morningSatiety.toInt()
        }
        else if (morningSatiety == "0" ){
        }
        else{
            Toast.makeText(applicationContext," morningSatiety is invalid",Toast.LENGTH_SHORT).show()
        }


        if(noonHunger != "0" && noonHunger.toInt()>0){
            counter.counter++
            counter.sum += noonHunger.toInt()
        }
        else if (noonHunger == "0" ){
        }
        else{
            Toast.makeText(applicationContext," noonHunger is invalid",Toast.LENGTH_SHORT).show()
        }



        if(noonSatiety != "0" && noonSatiety.toInt()>0){
            counter.counter++
            counter.sum += noonSatiety.toInt()
        }
        else if (noonSatiety == "0" ){
        }
        else{
            Toast.makeText(applicationContext," noonSatiety is invalid",Toast.LENGTH_SHORT).show()
        }



        if(dinnerHunger != "0" && dinnerHunger.toInt()>0){
            counter.counter++
            counter.sum += dinnerHunger.toInt()
        }
        else if (dinnerHunger == "0" ){
        }
        else{
            Toast.makeText(applicationContext," dinnerHunger is invalid",Toast.LENGTH_SHORT).show()
        }



        if(dinnerSatiety != "0" && dinnerSatiety.toInt()>0){
            counter.counter++
            counter.sum += dinnerSatiety.toInt()
        }
        else if (dinnerSatiety == "0" ){
        }
        else{
            Toast.makeText(applicationContext," dinnerSatiety is invalid",Toast.LENGTH_SHORT).show()
        }

        //arithmetic
        val arithmetic = counter.sum/counter.counter
        findViewById<TextView>(R.id.arithmetic).text = arithmetic.toString()

        counter.counter = 0
        counter.sum = 0


        //mood
        val radioMood  = findViewById<RadioGroup>(R.id.radioMood)
        val mood = (findViewById<View>(radioMood.checkedRadioButtonId) as RadioButton).text.toString()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "mood" , mood).apply()

    }

    fun reset(view: View){

        val sharedPreferences1 = this.getSharedPreferences("com.meliskara.sugarcheckapplication",
            Context.MODE_PRIVATE)

        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "morningHunger", "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "morningSatiety",  "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "noonHunger", "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "noonSatiety", "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "dinnerHunger", "0").apply()
        sharedPreferences1.edit().putString(LoginActivity.oUSER.oUser + "dinnerSatiety", "0").apply()

        findViewById<TextView>(R.id.morningHunger).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningHunger", "0")
        findViewById<TextView>(R.id.morningSatiety).text =sharedPreferences1.getString(LoginActivity.oUSER.oUser + "morningHunger", "0")

        findViewById<TextView>(R.id.noonHunger).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonHunger", "0")
        findViewById<TextView>(R.id.noonSatiety).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "noonSatiety", "0")


        findViewById<TextView>(R.id.dinnerHunger).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerHunger", "0")
        findViewById<TextView>(R.id.dinnerSatiety).text = sharedPreferences1.getString(LoginActivity.oUSER.oUser + "dinnerSatiety", "0")

        findViewById<TextView>(R.id.arithmetic).text = "0"


    }


    fun returnToMain(view: View){
        startActivity(Intent(this,MainActivity::class.java))
    }

    fun graphToSugar(view: View){
        startActivity(Intent(this,SugarLevelsGraph::class.java))
    }

}